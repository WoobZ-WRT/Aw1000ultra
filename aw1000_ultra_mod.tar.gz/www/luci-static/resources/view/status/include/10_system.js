'use strict';
'require baseclass';
'require fs';
'require rpc';

var callSystemBoard = rpc.declare({object: 'system', method: 'board'});
var callSystemInfo = rpc.declare({object: 'system', method: 'info'});

return baseclass.extend({
    title: _('System'),
    load: function() {
        return Promise.all([
            L.resolveDefault(callSystemBoard(), {}),
            L.resolveDefault(callSystemInfo(), {}),
            fs.lines('/usr/lib/lua/luci/version.lua'),
            fetch('/cgi-bin/get_temp').then(function(res){return res.text();}).catch(function(){return "";}),
            fetch('/cgi-bin/get_cpu').then(function(res){return res.text();}).catch(function(){return "";})
        ]);
    },
    render: function(data) {
        var boardinfo = data[0];
        var systeminfo = data[1];
        var luciversion = data[2];
        var tempraw = data[3] ? data[3].trim() : '';
        var cpuraw = data[4] ? data[4].trim() : '';

        luciversion = luciversion.filter(function(l) {
            return l.match(/^\s*(luciname|luciversion)\s*=/);
        }).map(function(l) {
            return l.replace(/^\s*\w+\s*=\s*['"]([^'"]+)['"].*$/, '$1');
        }).join(' ');

        var datestr = null;
        if (systeminfo.localtime) {
            var date = new Date(systeminfo.localtime * 1000);
            datestr = '%02d:%02d:%02d  |  %02d-%02d-%04d'.format(
                date.getUTCHours(),
                date.getUTCMinutes(),
                date.getUTCSeconds(),
                date.getUTCDate(),
                date.getUTCMonth() + 1,
                date.getUTCFullYear()
            );
        }

        var tempcpu = 'N/A';
        if (tempraw && !isNaN(parseInt(tempraw))) {
            tempcpu = (parseInt(tempraw) / 1000).toFixed(1) + ' \xB0C';
        }

        var cpuusage = 'N/A';
        if (cpuraw !== '') {
            cpuusage = cpuraw;
        }

        var fields = [
            _('Model'), boardinfo.model,
            _('Architecture'), boardinfo.system,
            _('Firmware Version'), (boardinfo.release.description || '') + ' | Build WoobZ-WRT',
            _('Kernel Version'), boardinfo.kernel,
            _('Local Time'), datestr,
            _('Uptime'), systeminfo.uptime ? '%t'.format(systeminfo.uptime + (0 * 86400)) : null,
            _('Temperature'), tempcpu,
            _('CPU Usage'), cpuusage
        ];

        var table = E('table', {'class': 'table'});
        for (var i = 0; i < fields.length; i += 2) {
            table.appendChild(E('tr', {'class': 'tr'}, [
                E('td', {'class': 'td left', 'width': '33%'}, [fields[i]]),
                E('td', {'class': 'td left'}, [(fields[i+1] != null) ? fields[i+1] : '?'])
            ]));
        }
                                var routerImage = E('img', {
    'src': '/luci-static/material/navbar/telstra.png',
    'class': 'router-img', // <-- Tambahkan baris ini agar bisa ditarget oleh CSS
    'style': 'display: block; margin: 5px auto 2px auto; max-width: 100px; height: auto; border-radius: 8px;'
});

        
        // Trik siluman untuk melenyapkan teks "Status" dan "System"
        setTimeout(function() {
            document.querySelectorAll('h2, h3, legend').forEach(function(teks) {
                var isiTeks = teks.innerText || teks.textContent;
                if (isiTeks.trim() === 'Status' || isiTeks.trim() === 'System') {
                    teks.style.display = 'none';
                }
            });
        }, 10);
        
        // Menarik gambar dan tabel ke atas (-20px) agar lebih rapat
        return E('div', {'style': 'margin-top: 1px;'}, [routerImage, table]);
    }
});
