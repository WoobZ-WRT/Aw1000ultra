module("luci.controller.release_ram", package.seeall)

function index()
    entry({"admin", "status", "release_ram"}, call("release_ram"), _("Clear Cache"), 9999)
end

function release_ram()
    os.execute("sync; sync; echo 3 > /proc/sys/vm/drop_caches")
    os.execute("rm -rf /tmp/luci-modulecache/ /tmp/luci-indexcache/")
    luci.http.redirect(luci.dispatcher.build_url("admin", "status"))
end
