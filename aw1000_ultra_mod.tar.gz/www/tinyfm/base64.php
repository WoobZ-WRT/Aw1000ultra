<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>REYRE Base64 D/E</title>
    <style>
        :root {
            --card-bg: rgba(255, 255, 255, 0.85);
            --card-border: rgba(255, 255, 255, 0.3);
            --text-main: #0f172a;
            --text-muted: #64748b;
            --accent-primary: #000;
            --accent-gradient: #000;
            --input-bg: rgba(255, 255, 255, 0.7);
            --input-border: #cbd5e1;
            --shadow: 0 20px 25px -5px rgba(0, 0, 0, 0.2), 0 8px 10px -6px rgba(0, 0, 0, 0.1);
            --danger-color: #9b0000;
        }

        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
            transition: background-color 0.3s ease, border-color 0.3s ease, color 0.3s ease;
        }

        body {
            font-family: 'Plus Jakarta Sans', sans-serif;
            min-height: 100vh;
            display: flex;
            align-items: flex-start;
            justify-content: center;
            padding: .5rem;
            color: var(--text-main);
        }

        .container-card {
            width: 100%;
            background: var(--card-bg);
            backdrop-filter: blur(16px);
            -webkit-backdrop-filter: blur(16px);
            border: 1px solid var(--card-border);
            border-radius: 1.5rem;
            box-shadow: var(--shadow);
            padding: 1rem;
            position: relative;
            animation: fadeIn 0.5s ease-out;
        }

        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(15px); }
            to { opacity: 1; transform: translateY(0); }
        }

        .card-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 1rem;
        }

        .card-title {
            font-size: 1.5rem;
            font-weight: 700;
            background: var(--accent-gradient);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            display: flex;
            align-items: center;
            gap: 0.5rem;
        }

        /* Custom Tab Radio */
        .tab-container {
            display: flex;
            background: var(--input-bg);
            border: 1px solid var(--input-border);
            border-radius: 0.75rem;
            padding: 0.25rem;
            margin-bottom: 1.5rem;
        }

        .tab-btn {
            flex: 1;
            padding: 0.6rem 1rem;
            border: none;
            background: transparent;
            color: var(--text-muted);
            font-weight: 600;
            font-size: 0.9rem;
            border-radius: 0.5rem;
            cursor: pointer;
            transition: all 0.2s ease;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 0.4rem;
        }

        .tab-btn.active {
            background: #002b49;
            color: #ffffff;
            box-shadow: 0 4px 12px rgba(99, 102, 241, 0.3);
        }

        .editor-grid {
            display: grid;
            grid-template-columns: 1fr;
            gap: 1.25rem;
            align-items: start;
        }

        @media (min-width: 768px) {
            .editor-grid {
                grid-template-columns: 1fr 1fr;
            }
        }

        .form-group {
            display: flex;
            flex-direction: column;
            gap: 0.5rem;
            height: 100%;
        }

																	 
        .label-wrapper {
            display: flex;
            justify-content: space-between;
            align-items: center;
            min-height: 2.25rem; 
        }

        label {
            font-weight: 600;
            font-size: 0.9rem;
            color: var(--text-main);
            display: flex;
            align-items: center;
            gap: 0.4rem;
        }

        .form-textarea {
            width: 100%;
            min-height: 20rem;
            background: var(--input-bg);
            border: 1px solid var(--input-border);
            border-radius: 0.75rem;
            padding: 1rem;
            color: var(--text-main);
            font-family: 'Fira Code', monospace;
            font-size: 0.875rem;
            resize: vertical;
            outline: none;
            box-shadow: inset 0 2px 4px rgba(0,0,0,0.02);
        }

        .form-textarea:focus {
            border-color: var(--accent-primary);
            box-shadow: 0 0 0 3px rgba(99, 102, 241, 0.25);
        }

        .action-button-small {
            background: transparent;
            border: 1px solid var(--input-border);
            color: var(--text-main);
            padding: 0.35rem 0.75rem;
            font-size: 0.8rem;
            font-weight: 500;
            border-radius: 0.5rem;
            cursor: pointer;
            display: flex;
            align-items: center;
            gap: 0.3rem;
            transition: all 0.2s ease;
        }

        .action-button-small:hover {
            background: var(--accent-primary);
            color: #fff;
            border-color: var(--accent-primary);
        }

        .action-button-small.clear-btn:hover {
            background: var(--danger-color);
            color: #fff;
            border-color: var(--danger-color);
        }

        .toast {
            position: fixed;
            bottom: 2rem;
            right: 2rem;
            background: #002b49;
            color: white;
            padding: 0.75rem 1.25rem;
            border-radius: 0.5rem;
            font-weight: 600;
            font-size: 0.875rem;
            box-shadow: 0 10px 15px -3px rgba(0,0,0,0.3);
            opacity: 0;
            transform: translateY(10px);
            pointer-events: none;
            transition: all 0.3s cubic-bezier(0.68, -0.55, 0.265, 1.55);
            display: flex;
            align-items: center;
            gap: 0.5rem;
        }

        .toast.show {
            opacity: 1;
            transform: translateY(0);
        }
    </style>
</head>
<body>

<div class="container-card">
    <div class="card-header">
        <h3 class="card-title">
            <svg width="24" height="24" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" d="M8 9l3 3-3 3m5 0h3M5 20h14a2 2 0 002-2V6a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z"/></svg>
            Base64 Studio
        </h3>
    </div>

    <!-- Tab Modes -->
    <div class="tab-container">
        <button class="tab-btn active" data-mode="decode">
            <svg width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" d="M8 11V7a4 4 0 118 0m-4 8v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2z"/></svg>
            Decode Base64
        </button>
        <button class="tab-btn" data-mode="encode">
            <svg width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z"/></svg>
            Encode Base64
        </button>
    </div>

    <div class="editor-grid">
        <!-- Input Section -->
        <div class="form-group">
            <div class="label-wrapper">
                <label for="input">
                    <svg width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z"/></svg>
                    Input Teks
                </label>
                <button id="clearInput" class="action-button-small clear-btn">
                    <svg width="14" height="14" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"/></svg>
                    Clear Text
                </button>
            </div>
            <textarea id="input" placeholder="Enter text here..." class="form-textarea"></textarea>
        </div>

        <!-- Output Section -->
        <div class="form-group">
            <div class="label-wrapper">
                <label for="output">
                    <svg width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"/></svg>
                    Process Results
                </label>
                <button id="copyResult" class="action-button-small">
                    <svg width="14" height="14" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 16H6a2 2 0 01-2-2V6a2 2 0 012-2h8a2 2 0 012 2v2m-6 12h8a2 2 0 002-2v-8a2 2 0 00-2-2h-8a2 2 0 00-2 2v8a2 2 0 002 2z"></path></svg>
                    Copy Results
                </button>
            </div>
            <textarea id="output" placeholder="Results will appear here automatically...." class="form-textarea" readonly></textarea>
        </div>
    </div>
</div>

<div id="toast" class="toast">
    <svg width="18" height="18" fill="none" stroke="currentColor" stroke-width="2.5" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" d="M5 13l4 4L19 7"/></svg>
    <span id="toastText">Tersalin ke clipboard!</span>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    let currentMode = 'decode';
    
    const inputTextArea = document.getElementById('input');
    const outputTextArea = document.getElementById('output');
    const clearButton = document.getElementById('clearInput');
    const copyButton = document.getElementById('copyResult');
    const toast = document.getElementById('toast');
    const toastText = document.getElementById('toastText');
    const tabBtns = document.querySelectorAll('.tab-btn');

    // Toggle Mode Tab
    tabBtns.forEach(btn => {
        btn.addEventListener('click', () => {
            tabBtns.forEach(b => b.classList.remove('active'));
            btn.classList.add('active');
            currentMode = btn.getAttribute('data-mode');
            processText();
        });
    });

    function base64Encode(str) {
        try {
            const encoder = new TextEncoder();
            const data = encoder.encode(str);
            return btoa(String.fromCharCode(...data));
        } catch (e) {
            return 'Error: Failed to encode.';
        }
    }

    function base64Decode(str) {
        try {
            const binaryString = atob(str.trim());
            const len = binaryString.length;
            const bytes = new Uint8Array(len);
            for (let i = 0; i < len; i++) {
                bytes[i] = binaryString.charCodeAt(i);
            }
            const decoder = new TextDecoder();
            let decodedText = decoder.decode(bytes);
            try {
                const jsonObject = JSON.parse(decodedText);
                return JSON.stringify(jsonObject, null, 2);
            } catch (e) {
                return decodedText;
            }
        } catch (e) {
            return 'Error: Invalid Base64 input.';
        }
    }

    function processText() {
        const inputValue = inputTextArea.value;
        if (inputValue.trim() === '') {
            outputTextArea.value = '';
            return;
        }

        if (currentMode === 'encode') {
            outputTextArea.value = base64Encode(inputValue);
        } else {
            outputTextArea.value = base64Decode(inputValue);
        }
    }
    
    inputTextArea.addEventListener('input', processText);

    // Clear Button Handler
    clearButton.addEventListener('click', function() {
        inputTextArea.value = '';
        outputTextArea.value = '';
        inputTextArea.focus();
    });

    // Dynamic Copy Handler
    copyButton.addEventListener('click', function() {
        const textToCopy = outputTextArea.value;
        if (!textToCopy) return;

        if (navigator.clipboard && window.isSecureContext) {
            navigator.clipboard.writeText(textToCopy).then(() => {
                showToast('Copied!');
            }).catch(() => {
                fallbackCopyText(textToCopy);
            });
        } else {
            fallbackCopyText(textToCopy);
        }
    });

    function fallbackCopyText(text) {
        const tempTextArea = document.createElement('textarea');
        tempTextArea.value = text;
        tempTextArea.style.position = 'fixed';
        tempTextArea.style.left = '-9999px';
        tempTextArea.style.top = '0';
        document.body.appendChild(tempTextArea);
        tempTextArea.focus();
        tempTextArea.select();
        
        try {
            document.execCommand('copy');
            showToast('Copied!');
        } catch (err) {
            showToast('Failed to copy!');
        }
        
        document.body.removeChild(tempTextArea);
    }

    function showToast(msg) {
        toastText.textContent = msg;
        toast.classList.add('show');
        setTimeout(() => toast.classList.remove('show'), 2000);
    }
});
</script>
</body>
</html>