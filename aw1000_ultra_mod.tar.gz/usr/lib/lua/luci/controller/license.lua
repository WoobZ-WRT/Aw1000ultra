module("luci.controller.license", package.seeall)

function index()
    entry({"admin", "license"}, call("action_license"), nil, 99).dependent = false
end

function action_license()
    local http = require "luci.http"
    local uci = require "luci.model.uci".cursor()
    local sys = require "luci.sys"
    
    -- Baca MAC Address br-lan
    local mac = sys.exec("cat /sys/class/net/br-lan/address 2>/dev/null"):gsub("%s+", ""):upper()
    
    -- Buat Rumus Kode (MAC + KODEKU, diacak MD5, ambil 8 huruf pertama)
    local expected_key = sys.exec("echo -n '" .. mac .. "WOOBZWRT' | md5sum | cut -c 1-8"):gsub("%s+", ""):upper()
    
    local input_kode = http.formvalue("license_code")
    if input_kode then
        input_kode = input_kode:gsub("%s+", ""):upper()
        if input_kode == expected_key then
            uci:set("woobz_license", "status", "activated", "1")
            uci:commit("woobz_license")
            http.redirect(luci.dispatcher.build_url("admin"))
            return
        else
            luci.template.render("license_view", { error = true, mac_addr = mac })
            return
        end
    end
    luci.template.render("license_view", { error = false, mac_addr = mac })
end
