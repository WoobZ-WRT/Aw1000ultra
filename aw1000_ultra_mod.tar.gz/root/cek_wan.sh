#!/bin/sh

# Nama interface di modem Telstra (sesuaikan jika berbeda, misal: wan1 atau mob1s1a1)
IFACE_TELSTRA="wan"

# 1. CEK PENGUNCI: Kalau file ini ada, Cron yang baru datang akan disuruh pulang (batal ngecek).
if [ -f /tmp/wan_cooldown ]; then
    exit 0
fi

if ping -c 3 -W 3 8.8.8.8 > /dev/null; then
    exit 0
else
    logger "Ping Timeout: No internet. Restarting local WAN interface...."
    
    # ---> TAMBAHAN: Menyimpan catatan jam & tanggal ke file teks permanen
    echo "$(date): Ping Timeout: No internet. Restarting local WAN interface...." >> /root/log_restart_wan.txt

    # ---> FITUR BARU: Membatasi file log maksimal hanya 25 baris terakhir
    tail -n 25 /root/log_restart_wan.txt > /tmp/log_temp.txt
    mv /tmp/log_temp.txt /root/log_restart_wan.txt
    
    # 2. PASANG PENGUNCI: Menandai bahwa proses restart sedang dimulai
    touch /tmp/wan_cooldown
    
    # EKSEKUSI LANGSUNG (Tanpa dbclient/SSH)
    ifdown $IFACE_TELSTRA
    sleep 5
    ifup $IFACE_TELSTRA
    
    # 3. COOLDOWN 15 DETIK: Jeda aman agar Telstra selesai menyala
    sleep 15
    
    # 4. CABUT PENGUNCI: Menghapus tanda agar sistem pemantauan normal berjalan lagi
    rm -f /tmp/wan_cooldown
fi
